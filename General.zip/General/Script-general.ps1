if ((Get-ComputerInfo | Select-Object OSName) -like ('*Microsoft Windows 10*'))
{
    Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -force
    function Test-Administrator {  
        [OutputType([bool])]
        param()
        process 
        {
            [Security.Principal.WindowsPrincipal]$user = [Security.Principal.WindowsIdentity]::GetCurrent();
            return $user.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator);
        }
    }


    function 7Zip {
    Start-Process -Wait "$PSScriptRoot\assets\7-ZIP\7ZIP.exe" -Args "/S" -NoNewWindow
    regedit /s "$PSScriptRoot\assets\7-ZIP\Asociar.reg"
    }

    function irfanview {
    #Instalamos el programa.
    Start-Process -Wait "$PSScriptRoot\assets\Irfanviewer\IRFANVIEWER.exe" -Args "/silent /desktop=0 /thumbs=0 /group=1" -NoNewWindow
    #Instalamos los Plugins.
    Start-Process -Wait "$PSScriptRoot\assets\Irfanviewer\PLUGINS.exe" -Args "/silent" -NoNewWindow
    #Copiamos el idioma Espa�ol.
    Copy-Item -Force "$PSScriptRoot\assets\Irfanviewer\Languages\*" -Destination "$env:ProgramFiles\IrfanView\languages\" -ErrorAction SilentlyContinue
    }

    function activarF8 {
    start-process bcdedit.exe -args "/set {default} bootmenupolicy legacy" -NoNewWindow
    }

    function desactHiberna {
    powercfg /h off
    }

    function desactivarJavaUpdate {
    reg add "HKLM\SOFTWARE\Wow6432Node\JavaSoft\Java Update\Policy" /v EnableAutoUpdateCheck /d 0 /f
    reg add "HKLM\SOFTWARE\Wow6432Node\JavaSoft\Java Update\Policy" /v EnableJavaUpdate /d 0 /f
    }

    function desactAnimPrimInicio{
    New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation -PropertyType DWord -Value 0 -Force
    }

    function personalizar{

    #Quitamos noticias e intereses (usuario).
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Feeds" /v ShellFeedsTaskbarViewMode /t REG_DWORD /d 2 /f
    #Impedimos agrupar en la barra de tareas.
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarGlomLevel /t REG_DWORD /d 2 /f
    #Quitamos visor de tareas.
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowTaskViewButton /t REG_DWORD /d 0 /f
    #Quitamos Escritura a mano
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\PenWorkspace" /v PenWorkspaceButtonDesiredVisibility /t REG_DWORD /d 0 /f
    #Quitamos barra de busqueda (dejamos lupa)
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v SearchboxTaskbarMode /t REG_DWORD /d 1 /f
    #Desactivamos Apps en segundo plano.
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v Migrated /t REG_DWORD /d 4 /f
    #Colocamos 7-Zip en Espa�ol.
    reg add "HKEY_CURRENT_USER\SOFTWARE\7-Zip" /v Lang /t REG_SZ /d Es /f
    #Quitamos Reunirse Ahora.
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v HideSCAMeetNow /t REG_DWORD /d 1 /f
    #Desactivamos busqueda en internet desde el men� inicio.
    reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d 0 /f


    #Reiniciamos Explorer.
    taskkill /f /im explorer.exe
    start explorer.exe
    }

    function configUsuarios {
    #Realizamos la configuraciones en todos los usuarios.
    $carpUsuarios = Get-ChildItem "$env:systemdrive\users\" -Exclude Public  | ?{ $_.PSIsContainer } | Select-Object Name
    $i = $carpUsuarios.count
    While ($i -gt 0){
     Do{

      $i--
      $rutaUsuario = "$env:systemdrive\users\" + $carpUsuarios.Get($i).name + "\"

      #Copiamos configuraci�n de Irfanviewer.
      Copy-Item -Path "$PSScriptRoot\Assets\IrfanViewer\Appdata\*" -Recurse -Destination "$rutaUsuario" -Container -force -ErrorAction SilentlyContinue
  
      #Cambiamos registros de los usuarios.
      reg load hklm\regUsuario "$rutaUsuario\NTUSER.DAT"

        #Quitamos noticias e intereses (usuario).
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Feeds" /v ShellFeedsTaskbarViewMode /t REG_DWORD /d 2 /f
        #Impedimos agrupar en la barra de tareas.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarGlomLevel /t REG_DWORD /d 2 /f
        #Quitamos visor de tareas.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowTaskViewButton /t REG_DWORD /d 0 /f
        #Quitamos Escritura a mano
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\PenWorkspace" /v PenWorkspaceButtonDesiredVisibility /t REG_DWORD /d 0 /f
        #Quitamos barra de busqueda (dejamos lupa)
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v SearchboxTaskbarMode /t REG_DWORD /d 1 /f
        #Desactivamos Apps en segundo plano.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v Migrated /t REG_DWORD /d 4 /f
        #Colocamos 7-Zip en Espa�ol.
        reg add "HKLM\regUsuario\SOFTWARE\7-Zip" /v Lang /t REG_SZ /d Es /f
        #Quitamos Reunirse Ahora.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v HideSCAMeetNow /t REG_DWORD /d 1 /f
        #Desactivamos busqueda en internet desde el men� inicio.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d 0 /f

      reg unload hklm\regUsuario 
      }
      Until ($i -le 0)
    }

    #Copiamos el Appdata al usuario Default.
    Copy-Item -Path "$PSScriptRoot\Assets\IrfanViewer\Appdata\*" -Recurse -Destination "$env:systemdrive\users\default\" -Container -force -ErrorAction SilentlyContinue
  
    #Cambiamos registros del usuario Default.

      reg load hklm\regUsuario "$env:systemdrive\users\default\NTUSER.DAT"

        #Quitamos noticias e intereses (usuario).
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Feeds" /v ShellFeedsTaskbarViewMode /t REG_DWORD /d 2 /f
        #Impedimos agrupar en la barra de tareas.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarGlomLevel /t REG_DWORD /d 2 /f
        #Quitamos visor de tareas.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowTaskViewButton /t REG_DWORD /d 0 /f
        #Quitamos Escritura a mano
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\PenWorkspace" /v PenWorkspaceButtonDesiredVisibility /t REG_DWORD /d 0 /f
        #Quitamos barra de busqueda (dejamos lupa)
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v SearchboxTaskbarMode /t REG_DWORD /d 1 /f
        #Desactivamos Apps en segundo plano.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v Migrated /t REG_DWORD /d 4 /f
        #Colocamos 7-Zip en Espa�ol.
        reg add "HKLM\regUsuario\SOFTWARE\7-Zip" /v Lang /t REG_SZ /d Es /f
        #Quitamos Reunirse Ahora.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v HideSCAMeetNow /t REG_DWORD /d 1 /f
        #Desactivamos busqueda en internet desde el men� inicio.
        reg add "HKLM\regUsuario\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d 0 /f
  
      reg unload hklm\regUsuario 

        #Quitamos noticias e intereses (desactivamos por pol�tica).
        reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds" /v EnableFeeds /t REG_DWORD /d 0 /f
    }

    function psWU {
    Install-PackageProvider -Name NuGet -Confirm:$false -force
    Install-Module PSWindowsUpdate -Confirm:$False -Force
    Add-WUServiceManager -MicrosoftUpdate -Confirm:$false
    }

    function winget {
    DISM.EXE /Online /Add-ProvisionedAppxPackage /PackagePath:"$PSScriptRoot\assets\APPX\Winget.Msixbundle" /SkipLicense
    Add-AppxPackage -Path "$PSScriptRoot\assets\APPX\Winget.Msixbundle" -ErrorAction SilentlyContinue
    }



    #Testeamos y elevamos eventualmente privilegios.
    if(-not (Test-Administrator))
    {
        # TODO: define proper exit codes for the given errors 
        $mypath = $MyInvocation.MyCommand.Path
        $arguments = "-file", '"',$mypath,'"'
        start-process powershell -verb runas -ArgumentList $arguments
        exit 1;
    }
    $ErrorActionPreference = "Stop";

    Write-Host "Instalando 7-ZIP."
    7zip

    Write-Host "Instalando Irfanviewer."
    irfanview

    Write-Host "Activando F8."
    activarF8

    Write-Host "Desactivando hibernaci�n."
    desactHiberna

    Write-Host "Desactivando Java update."
    desactivarJavaUpdate

    Write-Host "Desactivando animaci�n de primer inicio de usuarios."
    desactAnimPrimInicio

    Write-Host "Personalizando el perfil de usuario."
    personalizar

    Write-Host Configuramos todos los usuarios.
    configUsuarios

    Write-Host "Instalando WinGet."
    winget


    Write-Host "Instalando Chocolatey"
    Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

    Write-Host "Ejecutando script de ChrisTitus."
    Start-Process -Wait "Invoke-WebRequest" -Args "-useb https://christitus.com/win | iex"

    Write-Host "Instalando PsWindowsUpdate."
    psWU

}

else{

Write-Host Este script est� dise�ado para funcionar �nicamente en Windows 10 a partir de la update 1903.
pause

}
